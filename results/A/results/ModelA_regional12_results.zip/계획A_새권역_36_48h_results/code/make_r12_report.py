"""Tables (markdown, every number read from result files) and figures for the Regional12 + 36/48 h report.
Usage: python make_r12_report.py <out.md> <check.json from score_r12 check> <mapdata folder>
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import colors, font_manager
from matplotlib.patches import Polygon

from a_r12 import CONDITIONS, FOREIGN
from config import RESULTS

HERE = Path(__file__).resolve().parent
FIG = HERE / "figures_r12"
FIG.mkdir(exist_ok=True)
for f in ("HANDotum.ttf", "HANDotumB.ttf"):
    font_manager.fontManager.addfont("C:/Windows/Fonts/" + f)
plt.rcParams.update({"font.family": "HCR Dotum", "axes.unicode_minus": False, "font.size": 9})
H = (3, 6, 12, 24, 36, 48)
KO = {"CN_SHANDONG": "산둥", "CN_BTH": "베이징·톈진·허베이", "CN_LIAONING": "랴오닝", "CN_JILIN": "지린",
      "CN_HEILONGJIANG": "헤이룽장", "CN_INNER_MONGOLIA": "중국 내몽골", "CN_OTHER": "기타 중국 동부(장쑤·안후이·저장)",
      "JP_WEST": "일본 서부", "JP_EAST": "일본 동부·중부", "MN": "몽골"}
M = lambda c: f"A_SARIMAX__R12_{c}"
fz = lambda x, d: (f"{0:.{d}f}" if round(x, d) == 0 else f"{x:+.{d}f}")

# ---------- collect metrics and tests: 3-24 h team scorer, 36/48 h supplementary ----------
mt = pd.read_csv(RESULTS / "score_r12_team" / "metrics.csv")
mt = mt[mt.prediction_kind == "single"][["horizon", "model", "n", "RMSE", "MAE", "MBE", "RMSE_improvement_pct"]]
me = pd.read_csv(RESULTS / "score_r12_ext" / "metrics.csv")[["horizon", "model", "n", "RMSE", "MAE", "MBE", "RMSE_improvement_pct"]]
met = pd.concat([mt, me], ignore_index=True)
tt = pd.read_csv(RESULTS / "score_r12_team" / "tests.csv")
tt["model"], tt["versus"] = tt.run_id.str.split("|").str[0], tt.versus_run_id.str.split("|").str[0]
te = pd.read_csv(RESULTS / "score_r12_ext" / "tests.csv")
tests = pd.concat([tt[["horizon", "model", "versus", "rmse_diff", "p", "p_holm", "ci95_low", "ci95_high", "improved"]],
                   te[["horizon", "model", "versus", "rmse_diff", "p", "p_holm", "ci95_low", "ci95_high", "improved"]]],
                  ignore_index=True)
v = lambda model, h, col: float(met[(met.model == model) & (met.horizon == h)][col].iloc[0])
tr = lambda a, b, h: tests[(tests.model == a) & (tests.versus == b) & (tests.horizon == h)].iloc[0]
check = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
nrows = {h: int(met[(met.model == "persistence") & (met.horizon == h)].n.iloc[0]) for h in H}

L = {c: json.loads((RESULTS / "r12" / f"{c}.json").read_text(encoding="utf-8")) for c in CONDITIONS}
conv = all(L[c]["by_horizon"][str(h)]["converged"] for c in CONDITIONS for h in H)

md = []
row = lambda cells: "| " + " | ".join(cells) + " |"
hdr = lambda first: [row([first] + [f"{h}h" for h in H]), row(["---"] * 7)]

# gain table data
gain = {}
for c in ["F"] + [f"ADD_{r}" for r in FOREIGN]:
    for h in H:
        r = tr(M(c), M("DN"), h)
        gain[(c, h)] = (-r.rmse_diff, bool(r.improved), -r.rmse_diff / v(M("DN"), h, "RMSE") * 100)

# ---------- 한눈에 보기 (claims computed from the numbers) ----------
sig_regions = {h: [KO[c[4:]] for c in [f"ADD_{r}" for r in FOREIGN] if gain[(c, h)][1]] for h in H}
best = {h: max([f"ADD_{r}" for r in FOREIGN], key=lambda c: gain[(c, h)][0]) for h in H}
f_sig = [h for h in H if gain[("F", h)][1]]
dn_sig = [h for h in H if tr(M("DN"), "A_SARIMA", h).improved] if False else None
facts = {"sig_regions": sig_regions, "best": {h: (best[h], round(gain[(best[h], h)][0], 3)) for h in H},
         "F_sig_h": f_sig, "conv": conv}
(FIG / "facts.json").write_text(json.dumps(facts, ensure_ascii=False, indent=1), encoding="utf-8")

# ---------- 표 1 기준선 + SARIMA ----------
md += ["■ 표 1. 기준선과 SARIMA (2023 검증, RMSE / persistence 대비 개선률 %)", ""]
md += hdr("모델")
for lab, mod in (("Persistence", "persistence"), ("Seasonal naive", "seasonal_naive"), ("SARIMA", "A_SARIMA")):
    md.append(row([lab] + [f"{v(mod, h, 'RMSE'):.2f} / {v(mod, h, 'RMSE_improvement_pct'):.1f}%" for h in H]))
md.append(row(["평가 행 수"] + [f"{nrows[h]:,}" for h in H]))
md += ["", "Seasonal naive는 36h·48h에서 팀 정의와 다름(1쪽 2번). 48h는 persistence와 같음.", ""]

# ---------- 표 2 DN, F ----------
md += ["■ 표 2. 국내 기준선 DN과 전체 F (RMSE / persistence 대비 개선률 %)", ""]
md += hdr("조건")
for lab, c in (("DN (국내 514 평균)", "DN"), ("F (국내 평균 + 국외 120 평균)", "F")):
    md.append(row([lab] + [f"{v(M(c), h, 'RMSE'):.2f} / {v(M(c), h, 'RMSE_improvement_pct'):.1f}%" for h in H]))
md.append(row(["DN의 SARIMA 대비 RMSE 차이"] + [f"{tr(M('DN'), 'A_SARIMA', h).rmse_diff:+.2f}" if False else
                                              f"{v(M('DN'), h, 'RMSE') - v('A_SARIMA', h, 'RMSE'):+.2f}" for h in H]))
md += ["", ""]

# ---------- 표 3 권역 추가 이득 ----------
md += ["■ 표 3. 권역 추가 이득 = RMSE(DN) − RMSE(조건) (µg/m³, 양수 = 좋아짐, * = 유의)", ""]
md += hdr("추가한 권역")
for c in ["F"] + [f"ADD_{r}" for r in FOREIGN]:
    lab = "국외 전체 (F)" if c == "F" else KO[c[4:]]
    md.append(row([lab] + [fz(gain[(c, h)][0], 2) + (" *" if gain[(c, h)][1] else "") for h in H]))
md += ["", "* = bootstrap 95% 구간 상한 < 0 이고 Holm 보정 p < 0.05. 3~24h는 팀 채점기, 36·48h는 보조 채점(1쪽 1번).", ""]

# ---------- 표 4 권역 계수 ----------
md += ["■ 표 4. 추가한 권역 평균의 계수 (log1p 단위, * = 95% 신뢰구간이 0을 포함하지 않음)", ""]
md += hdr("권역")
for c in ["F"] + [f"ADD_{r}" for r in FOREIGN]:
    grp = "FOREIGN" if c == "F" else c[4:]
    lab = "국외 전체 (F)" if c == "F" else KO[c[4:]]
    co = pd.DataFrame(L[c]["coefficients"])
    cells = []
    for h in H:
        r = co[(co.horizon == h) & co.term.str.startswith(grp + "_L")].iloc[0]
        cells.append(fz(r.coef, 3) + (" *" if (r.ci95_low > 0 or r.ci95_high < 0) else ""))
    md.append(row([lab] + cells))
md += ["", "모든 조건에 국내 평균(DOM)이 함께 들어 있으며, 위 값은 그 위에 추가한 권역 변수의 계수임.", ""]

# ---------- 지연 L (all equal to h is checked, else a table) ----------
allh = all(L[c]["by_horizon"][str(h)]["L"] == h for c in CONDITIONS for h in H)
if allh:
    md += ["■ 고른 지연 L", "", "12개 조건 × 6개 예측 시간 모두 L = h (후보 {h, h+3, h+6} 중 가장 최근 값)가 2023 RMSE로 선택됨.", ""]
else:
    md += ["■ 표 5. 고른 지연 L (시간)", ""] + hdr("조건")
    for c in CONDITIONS:
        md.append(row([c if c in ("DN", "F") else KO[c[4:]]] + [str(L[c]["by_horizon"][str(h)]["L"]) for h in H]))
    md += [""]

Path(sys.argv[1]).write_text("\n".join(md) + "\n", encoding="utf-8")

# ---------- 그림 1: 권역 추가 이득 히트맵 ----------
rows = ["F"] + [f"ADD_{r}" for r in FOREIGN]
labs = ["국외 전체 (F)"] + [KO[c[4:]] for c in rows[1:]]
Z = np.array([[gain[(c, h)][0] for h in H] for c in rows])
lim = max(0.6, float(np.abs(Z).max()))
cmap = colors.LinearSegmentedColormap.from_list("div", ["#d15a2a", "#f7f6f3", "#2a78d6"])
fig, ax = plt.subplots(figsize=(6.8, 4.6), dpi=220)
ax.imshow(Z, cmap=cmap, vmin=-lim, vmax=lim, aspect="auto")
for i, c in enumerate(rows):
    for j, h in enumerate(H):
        val, sig, _ = gain[(c, h)]
        ax.text(j, i, fz(val, 2) + ("*" if sig else ""), ha="center", va="center", fontsize=7.6,
                color="#0b0b0b", fontweight="bold" if sig else "normal")
ax.set_xticks(range(len(H)), [f"{h}h" for h in H]); ax.set_yticks(range(len(rows)), labs)
ax.axvline(3.5, color="#0b0b0b", lw=1.4)
ax.text(1.5, -0.7, "◀ 팀 채점기 (3~24h)", ha="center", va="bottom", fontsize=8, color="#0b0b0b")
ax.text(4.5, -0.7, "보조 채점, 팀 채점기 밖 (36·48h) ▶", ha="center", va="bottom", fontsize=8, color="#0b0b0b")
ax.set_title("그림 1. 국내 기준선(DN)에 권역 하나를 더했을 때 RMSE 감소량 (µg/m³)", loc="left", fontsize=10,
             fontweight="bold", pad=26)
ax.tick_params(length=0)
for s in ax.spines.values():
    s.set_visible(False)
fig.text(0.01, 0.01, "파랑 = 좋아짐, 주황 = 나빠짐, * = 유의. 2023 검증. 예측에 도움이 된 정도이며 오염 기여율이 아님.",
         fontsize=7, color="#52514e")
fig.tight_layout(rect=(0, 0.03, 1, 1))
fig.savefig(FIG / "fig1_gain_heatmap.png"); plt.close(fig)

# ---------- 그림 2: persistence 대비 개선률 (SARIMA, DN, F, 최대 이득 권역 없이) ----------
fig, ax = plt.subplots(figsize=(6.6, 3.5), dpi=220)
series = [("A_SARIMA", "SARIMA", "#6b6a66", "--"), (M("DN"), "DN (국내 514 평균)", "#2a78d6", "-"),
          (M("F"), "F (국내 + 국외 전체)", "#eb6834", "-")]
for k, (mod, lab, col, ls) in enumerate(series):
    x = np.arange(len(H)) + (k - 1) * 0.08
    y = [v(mod, h, "RMSE_improvement_pct") for h in H]
    lo, hi = [], []
    for h in H:
        r = tr(mod, "persistence", h)
        rp = v("persistence", h, "RMSE")
        lo.append(-r.ci95_high / rp * 100); hi.append(-r.ci95_low / rp * 100)
    ax.errorbar(x, y, yerr=[np.array(y) - lo, np.array(hi) - y], color=col, ls=ls, lw=2, marker="o", ms=4.5,
                mec="white", mew=0.8, elinewidth=0.9, capsize=2, label=lab)
ax.axvline(3.5, color="#52514e", lw=0.9, ls=":")
ax.text(3.58, ax.get_ylim()[0] + 0.6, "점선 오른쪽 36·48h: 보조 채점 (팀 채점기 밖)", fontsize=7.5, color="#52514e",
        va="bottom")
ax.axhline(0, color="#52514e", lw=0.8)
ax.set_xticks(range(len(H)), [f"{h}h" for h in H]); ax.set_xlabel("예측 시간")
ax.set_ylabel("persistence 대비 RMSE 개선률 (%)")
ax.set_title("그림 2. 예측 시간별 persistence 대비 개선률", loc="left", fontsize=10, fontweight="bold")
ax.grid(axis="y", color="#e2e1dd", lw=0.6)
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
ax.legend(frameon=False, fontsize=8, loc="upper left")
fig.tight_layout(); fig.savefig(FIG / "fig2_improvement.png"); plt.close(fig)

# ---------- 그림 3: 지도 (권역별 추가 이득, 6개 예측 시간) ----------
mapdir = Path(sys.argv[3])
reg = pd.read_csv(HERE.parent / "regional12" / "station_registry.csv", dtype=str, encoding="utf-8-sig")
reg[["longitude", "latitude"]] = reg[["longitude", "latitude"]].astype(float)
land = json.load(open(mapdir / "ne_50m_land.geojson", encoding="utf-8"))
ctry = json.load(open(mapdir / "ne_50m_admin_0_countries.geojson", encoding="utf-8"))
EXTN = (104, 145, 26.5, 51)


def rings(geom):
    polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"] if geom["type"] == "MultiPolygon" else []
    for p in polys:
        a = np.asarray(p[0])
        if a[:, 0].max() > EXTN[0] - 5 and a[:, 0].min() < EXTN[1] + 5 and a[:, 1].max() > EXTN[2] - 5 and a[:, 1].min() < EXTN[3] + 5:
            yield a


LAND = [r for f in land["features"] for r in rings(f["geometry"])]
BORD = [r for f in ctry["features"] for r in rings(f["geometry"])]
seq = colors.LinearSegmentedColormap.from_list("b", ["#cfe0f5", "#2a78d6", "#0d3f80"])
VMAX = max(0.3, max(gain[(f"ADD_{r}", h)][0] for r in FOREIGN for h in H))
norm = colors.Normalize(0, VMAX)
fig, axes = plt.subplots(3, 2, figsize=(6.8, 8.6), dpi=200)
for ax, h in zip(axes.flat, H):
    for r_ in LAND:
        ax.add_patch(Polygon(r_, closed=True, facecolor="#f1f0ec", edgecolor="none", zorder=0))
    for r_ in BORD:
        ax.add_patch(Polygon(r_, closed=True, facecolor="none", edgecolor="#b9b8b3", lw=0.35, zorder=1))
    kr = reg[reg.country == "KR"]
    ax.scatter(kr.longitude, kr.latitude, s=2.5, color="#c9c8c3", lw=0, zorder=2)
    for r in FOREIGN:
        val, sig, _ = gain[(f"ADD_{r}", h)]
        s = reg[reg.experiment_region_id == r]
        if sig:
            ax.scatter(s.longitude, s.latitude, s=12, color=seq(norm(max(val, 0))), edgecolor="white", lw=0.3, zorder=4)
        else:
            ax.scatter(s.longitude, s.latitude, s=10, facecolor="white", edgecolor="#8a8984", lw=0.6, zorder=3)
    ax.scatter(126.98, 37.57, marker="*", s=55, color="#0b0b0b", edgecolor="white", lw=0.4, zorder=6)
    ax.set_xlim(EXTN[0], EXTN[1]); ax.set_ylim(EXTN[2], EXTN[3]); ax.set_aspect(1 / np.cos(np.deg2rad(40)))
    ax.set_xticks([]); ax.set_yticks([])
    for s_ in ax.spines.values():
        s_.set_color("#b9b8b3"); s_.set_linewidth(0.5)
    ax.set_title(f"{h}시간 후 예측" + ("  (보조 채점)" if h > 24 else ""), fontsize=8.8, fontweight="bold", loc="left")
fig.suptitle("그림 3. 권역별 추가 이득 지도 (색 채운 점 = 유의하게 좋아짐, 빈 점 = 유의하지 않음, ★ = 서울 중구)",
             x=0.02, ha="left", fontsize=9.3, fontweight="bold")
fig.subplots_adjust(left=0.02, right=0.98, top=0.93, bottom=0.08, wspace=0.05, hspace=0.14)
cax = fig.add_axes([0.06, 0.045, 0.4, 0.014])
cb = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=seq), cax=cax, orientation="horizontal")
cb.set_label("RMSE(DN) − RMSE(DN+권역) (µg/m³)", fontsize=7); cb.ax.tick_params(labelsize=6.5); cb.outline.set_visible(False)
fig.text(0.52, 0.045, "회색 점 = 국내 514곳 (모든 조건에 포함). 지도: Natural Earth", fontsize=6.8, color="#52514e")
fig.savefig(FIG / "fig3_map.png"); plt.close(fig)
print("ok", facts)
