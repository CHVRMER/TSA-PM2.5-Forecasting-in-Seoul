"""Assemble the Regional12 + 36/48 h report markdown: page 1 (issues box), overview, tables from make_r12_report.
Every number on page 1 is read from files (check json, metrics, grid). Usage:
python assemble_r12.py <tables.md> <check.json> <facts.json> <out.md>
"""
import json
import sys
from pathlib import Path

import pandas as pd

from a_r12 import CONDITIONS
from config import RESULTS

tables = Path(sys.argv[1]).read_text(encoding="utf-8")
chk = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
facts = json.loads(Path(sys.argv[3]).read_text(encoding="utf-8"))
me = pd.read_csv(RESULTS / "score_r12_ext" / "metrics.csv")
n36 = int(me[(me.model == "persistence") & (me.horizon == 36)].n.iloc[0])
n48 = int(me[(me.model == "persistence") & (me.horizon == 48)].n.iloc[0])
gc = chk["grid"]
sc = chk["scorer"]
mx_metric = max(v for k, v in sc.items() if k.startswith("max|") and any(c in k for c in ("RMSE", "MAE", "MBE", "R2")))
mx_test = max(v for k, v in sc.items() if k.startswith("max|") and any(c in k for c in ("rmse_diff", "p", "ci95")))
KO = {"ADD_CN_SHANDONG": "산둥", "ADD_CN_BTH": "베이징·톈진·허베이", "ADD_CN_LIAONING": "랴오닝", "ADD_CN_JILIN": "지린",
      "ADD_CN_HEILONGJIANG": "헤이룽장", "ADD_CN_INNER_MONGOLIA": "중국 내몽골", "ADD_CN_OTHER": "기타 중국 동부",
      "ADD_JP_WEST": "일본 서부", "ADD_JP_EAST": "일본 동부·중부", "ADD_MN": "몽골"}

p = []
p += ["계획 A 추가 결과: 새 공통 권역(Regional12) + 36·48시간 예측", ""]
p += ["- 모델: SARIMA(2,1,2) + 하루·연간 Fourier, SARIMAX(권역 평균 외생변수). 2021–22 학습, 2023 검증. 2024 시험 구간은 열지 않음.",
      "- 새 권역·조건 목록: Regional12_Seed11_20261109.zip의 regions.json / experiments.json / station_registry.csv를 그대로 사용 (외부 634계열, 17권역).",
      "- 예측 시간: 3·6·12·24h(팀 기준) + 36·48h(추가).", ""]
p += ["■ 먼저 확인해 주세요: 문제점·주의점", ""]
p += [
    "! 36·48h는 팀 채점기로 채점하지 않음 (보조 채점) | 「Model/Common/grid.py」에는 \"Only 3/6/12/24-hour horizons are supported\"라는 검사가 있어 팀 채점기(score.py)가 36·48h를 받지 않음. "
    "그래서 팀 채점기 파일은 고치지 않고, 그 안의 함수(metric_values, calendar_errors, dm_calendar, bootstrap_calendar, holm)를 그대로 불러 같은 규칙으로 따로 계산함. "
    f"같은 보조 채점을 3~24h에 돌려 팀 채점기 결과와 비교한 결과, 지표 {sc['metric_rows'][2]}행·검정 {sc['test_rows'][2]}행이 모두 일치함 "
    f"(지표 최대 차이 {mx_metric:.1e}, 검정 최대 차이 {mx_test:.1e}, 유의 판정 {'모두 같음' if sc['improved_identical'] else '다름'}).",
    "! Seasonal naive 정의 문제는 아직 해결되지 않음 | 「Model/Common/README.txt」에는 \"Seasonal naive: t+h−24 실측\", 「grid.py」에는 정답 시각 − 24시간으로 구현되어 있음. "
    "36h면 t+12, 48h면 t+24로 예측 시점 이후 값(누출)이 됨. 보조 채점에서는 \"t까지 관측된 가장 최근 같은 시각 값\"(36h: t−12h, 48h: t)으로 바꿈. 48h에서는 persistence와 같아짐. "
    "3~24h는 팀 정의 그대로임. 36·48h를 팀에서 하려면 공통 정의를 정해야 함.",
    f"! 36·48h 정답·채점 행은 팀 규칙으로 새로 만듦 | 팀 평가 격자(evaluation_grid.parquet)에는 36·48h가 없음. 같은 규칙(정답 실측, 같은 분할, 2021–2024 안, 결측 미보간, persistence = t 이전 마지막 관측)으로 만들었고, "
    f"같은 코드로 만든 3~24h 행은 팀 격자와 {gc['rows_matched']:,}행 전부 일치함. 2023 검증 행 수: 36h {n36:,}, 48h {n48:,}.",
    "! 새 권역은 DCRNN 실행 설정을 A에 맞게 줄여 적용함 | Regional12 zip의 README와 experiments.json은 실행 모델을 DCRNN으로 지정함(\"DCRNN 최소 권역 실험\"). "
    "노션 「공통 관측소 권역 구분 및 실험 입력 조건」에는 \"권역 평균을 만드는 모델도 해당 조건에 허용된 관측소 목록에서만 평균을 계산합니다\"라고 적혀 있음. "
    "A는 권역 평균을 외생변수로 쓰므로: DN = 국내 514곳 평균 1개, ADD_권역 = 국내 평균 + 그 권역 평균, F = 국내 평균 + 국외 120곳 평균. "
    "17권역을 모두 넣으면 Fourier 포함 외생변수가 25개가 되어(노션 \"10개 안팎\" 코멘트와 충돌) 쓰지 않음. 조건 이름은 DCRNN과 같지만 입력 형태(관측소별 vs 권역 평균)는 다름.",
    "! SARIMAX 외생변수 결측 처리 기준이 글마다 다름 (방법은 바꾸지 않음) | 노션 「통합 예측 파이프라인 (A–D)」의 「1. 공통 규칙」 표 \"입력 결측\" 칸에는 "
    "\"SARIMAX 외생변수는 과거로만 최대 24시간 채운 뒤 2021–22 중앙값\"이라고 적혀 있음. 노션 데이터 품질 점검 글의 「제 모델 단계의 결측 처리」 표 A (SARIMAX) 칸에는 "
    "\"최대 6시간 직전 값으로 채우고, 그래도 비면 0(평균)\"이라고 적혀 있음. 이번 결과는 「1. 공통 규칙」 기준을 그대로 씀. "
    "기존 A 코드(Data_with_neighbors_v3의 Models/a_sarimax.py)도 같은 기준임.",
    "! 그 밖의 해석 주의 | 2023 검증 결과만 있음(지연 L도 2023으로 골라 2023 점수가 약간 유리함). Holm 보정은 3~24h(팀 채점기)와 36·48h(보조 채점)가 따로 묶여 있어 두 묶음의 p값을 직접 비교하면 안 됨. "
    "몽골은 2023년 82%가 결측임. 이상치는 바꾸지 않음(팀 규칙). SARIMAX는 시드가 없는 최대우도 추정이라 seed11 같은 시드 구분이 없음. "
    "권역 이득은 예측에 도움이 된 정도이며 오염 기여율이나 인과가 아님.",
]
p += ["", "@@PAGEBREAK"]

# overview, computed facts only
sig = facts["sig_regions"]
lines = ["■ 한눈에 보기", "", "| 예측 시간 | 국내 기준선(DN)에 더했을 때 유의하게 좋아진 국외 권역 | 이득이 가장 큰 권역 (µg/m³) |", "|---|---|---|"]
for h in ("3", "6", "12", "24", "36", "48"):
    b, g = facts["best"][h]
    lines.append(f"| {h}h{' (보조)' if int(h) > 24 else ''} | {', '.join(sig[h]) if sig[h] else '없음'} | {KO[b]} {g:+.2f} |")
lines += ["", f"국외 전체(F)가 DN보다 유의하게 좋았던 예측 시간: {', '.join(str(h) + 'h' for h in facts['F_sig_h']) if facts['F_sig_h'] else '없음'}. "
          f"모든 적합 수렴: {'예' if facts['conv'] else '아니오'} (12조건 × 6개 예측 시간 × 지연 후보 3개).", ""]
out = "\n".join(p + lines) + "\n" + tables + "\n■ 그림\n\n■ 파일\n\n" + "\n".join([
    "- 계획A_새권역_36_48h.pdf: 이 보고서",
    "- 계획A_새권역_36_48h_results.zip: 예측 파일(3~24h 팀 형식 / 36·48h 별도 폴더), 채점 결과(팀 채점기 3~24h, 보조 채점 36·48h, 3~24h 대조 결과), 조건별 지연·계수 기록, 코드",
]) + "\n"
Path(sys.argv[4]).write_text(out, encoding="utf-8")
print("ok")
