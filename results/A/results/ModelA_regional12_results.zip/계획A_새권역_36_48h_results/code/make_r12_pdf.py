"""팀공유_계획A_결과.md -> 팀공유_계획A_결과.pdf (same text, tables drawn as real tables).
Usage: python make_team_pdf.py <md> <pdf>
"""
import sys
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

FONTS = "C:/Windows/Fonts/"
for name, f in (("Batang", "HANBatang.ttf"), ("BatangB", "HANBatangB.ttf"), ("Dotum", "HANDotum.ttf"),
                ("DotumB", "HANDotumB.ttf")):
    pdfmetrics.registerFont(TTFont(name, FONTS + f))                  # 함초롬바탕 / 함초롬돋움 (한컴 기본 글꼴)
pdfmetrics.registerFontFamily("Batang", normal="Batang", bold="BatangB", italic="Batang", boldItalic="BatangB")
pdfmetrics.registerFontFamily("Dotum", normal="Dotum", bold="DotumB", italic="Dotum", boldItalic="DotumB")

INK = colors.black
title = ParagraphStyle("t", fontName="DotumB", fontSize=15, leading=21, textColor=INK, spaceAfter=8)
h2 = ParagraphStyle("h", fontName="DotumB", fontSize=11.5, leading=16, textColor=INK, spaceBefore=10, spaceAfter=5)
body = ParagraphStyle("b", fontName="Batang", fontSize=9.6, leading=14, textColor=INK)
bullet = ParagraphStyle("bl", parent=body, leftIndent=10, bulletIndent=0, bulletFontName="Batang")
note = ParagraphStyle("n", parent=body, fontSize=8.6, leading=12.5, textColor=INK)
cell = ParagraphStyle("c", fontName="Dotum", fontSize=8.6, leading=11.2, textColor=INK)
cell_c = ParagraphStyle("cc", parent=cell, alignment=TA_CENTER)
cell_h = ParagraphStyle("ch", parent=cell_c, fontName="DotumB")
cell_hl = ParagraphStyle("chl", parent=cell, fontName="DotumB")

W = A4[0] - 32 * mm


def table(rows):
    rows = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows]
    rows = [r for r in rows if not all(set(c) <= set("-: ") for c in r)]          # drop |---| separator
    ncol = len(rows[0])
    overview = ncol == 3 and rows[0][0] == "요구사항"
    left_cols = {0, 1} if overview else {0}
    data = []
    for i, r in enumerate(rows):
        out = []
        for j, c in enumerate(r):
            if i == 0:
                st = cell_hl if j in left_cols else cell_h
            else:
                st = cell if j in left_cols else cell_c
            out.append(Paragraph(escape(c), st))
        data.append(out)
    if overview:                                           # 한눈에 보기: 요구사항 | 결과 한 줄 | 표
        widths = [W * 0.20, W * 0.72, W * 0.08]
    else:
        first = 0.24 if ncol <= 5 else 0.20
        widths = [W * first] + [W * (1 - first) / (ncol - 1)] * (ncol - 1)
    t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def build(md_path, pdf_path):
    lines = open(md_path, encoding="utf-8").read().splitlines()
    story, i, pending = [], 0, []
    story.append(Paragraph(escape(lines[0]), title))
    i = 1

    def flush():
        if pending:
            story.append(KeepTogether(list(pending)))
            pending.clear()

    def figures():
        """그림 section (images only exist in the PDF, not in the .txt)."""
        story.append(PageBreak())
        story.append(Paragraph("그림", h2))
        for name, caption in FIGS:
            img = ImageReader(name)
            w, h = img.getSize()
            parts = [Image(name, width=W, height=W * h / w)]
            if caption:
                parts += [Spacer(1, 2), Paragraph(escape(caption), note)]
            story.append(KeepTogether(parts + [Spacer(1, 10)]))

    while i < len(lines):
        ln = lines[i]
        if ln.startswith("! "):                          # page-1 issue box: "! title | text"
            items = []
            while i < len(lines) and lines[i].startswith("! "):
                t_, _, d_ = lines[i][2:].partition("|")
                items.append([Paragraph(f"<b>{len(items) + 1}</b>", box_n),
                              Paragraph(f"<b>{escape(t_.strip())}</b><br/>{escape(d_.strip())}", box_t)])
                i += 1
            bx = Table(items, colWidths=[W * 0.05, W * 0.95], hAlign="LEFT")
            bx.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1.4, colors.black),
                                    ("LINEBELOW", (0, 0), (-1, -2), 0.4, colors.black),
                                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                                    ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                                    ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 6)]))
            flush()
            story.append(bx)
            continue
        if ln.strip() == "@@PAGEBREAK":
            flush()
            story.append(PageBreak())
            i += 1
            continue
        if ln.startswith("|"):
            block = []
            while i < len(lines) and lines[i].startswith("|"):
                block.append(lines[i]); i += 1
            pending.append(table(block)); pending.append(Spacer(1, 4))
            continue
        if ln.startswith("■"):
            flush()
            if ln.strip() == "■ 그림" and FIGS:
                figures()
                i += 1
                continue
            pending.append(Paragraph(escape(ln.lstrip("■ ").strip()), h2))
        elif ln.startswith("- "):
            pending.append(Paragraph(escape(ln[2:]), bullet, bulletText="•"))
        elif ln.startswith(("①", "②", "③")):
            pending.append(Paragraph("<b>" + escape(ln) + "</b>", body))
            pending.append(Spacer(1, 3))
        elif ln.startswith("* ") or ln.startswith("앞 숫자") or ln.startswith("몽골은"):
            pending.append(Paragraph(escape(ln), note))
        elif ln.strip():
            pending.append(Paragraph(escape(ln), body))
        else:
            pending.append(Spacer(1, 3))
        i += 1
    flush()

    def footer(c, d):
        c.setFont("Batang", 8.5); c.setFillColor(colors.black)
        c.drawCentredString(A4[0] / 2, 10 * mm, f"- {d.page} -")

    SimpleDocTemplate(pdf_path, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=15 * mm,
                      bottomMargin=16 * mm, title="계획 A 새 권역 36·48h", author="").build(story, onFirstPage=footer,
                                                                                 onLaterPages=footer)


FIGS = []
box_n = ParagraphStyle("bn", fontName="DotumB", fontSize=10, leading=13, textColor=colors.black, alignment=TA_CENTER)
box_t = ParagraphStyle("bt", fontName="Dotum", fontSize=8.8, leading=12.4, textColor=colors.black)

if __name__ == "__main__":
    d = sys.argv[3]
    bars = ("점 = persistence 대비 RMSE 개선률(2023 검증), 세로 막대 = 7일 블록 bootstrap 95% 구간(persistence 대비). "
            "점선 오른쪽(36·48h)은 팀 채점기 밖 보조 채점임.")
    FIGS = [(f"{d}/fig1_gain_heatmap.png", ""), (f"{d}/fig2_improvement.png", bars), (f"{d}/fig3_map.png", "")]
    build(sys.argv[1], sys.argv[2])
    print("ok")
